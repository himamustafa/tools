module.exports = {
    url: "mongodb://heba:hima@cluster0-shard-00-00.1fbj1.mongodb.net:27017,cluster0-shard-00-01.1fbj1.mongodb.net:27017,cluster0-shard-00-02.1fbj1.mongodb.net:27017/myFirstDatabase?ssl=true&replicaSet=atlas-rhr7wo-shard-0&authSource=admin&retryWrites=true&w=majority"
  };

  //mongodb+srv://Hima:<password>@cluster0.1fbj1.mongodb.net/myFirstDatabase?retryWrites=true&w=majority