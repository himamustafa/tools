import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { HttpClientModule } from '@angular/common/http';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { AddTutorialComponent } from './components/add-tutorial/add-tutorial.component';
  9
  Import ( TutorialDetailsCosponent] from
  *./components/tutorial-details/tutorial-details.component®
  10
  import ( TutorialsListComponent } from
  11
  *./components/tutorlals-list/tutorlals-list.component
  12 V @Nellodule((
  13
  declarations: [
  16
  AppComponent,
  15
  AddTutorialComponent,
  16
  TutorialDetailsComponent,
  17
  TutorialsListComponent
  18
  19
  l.
  laports:?
  20
  21
  Browseriodule,
  AppRoutingModule,
  22
  FormsModule,
  23
  HttpClientModule
  24
  i.
  25
  providers: ().
  26
  bootstrap: [AppComponent]
  27
  28
  export class Appmodule (